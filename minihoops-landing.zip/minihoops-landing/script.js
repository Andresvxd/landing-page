document.getElementById("form").addEventListener("submit", function(e){
    e.preventDefault();
    document.getElementById("mensaje").textContent = "✅ ¡Inscripción exitosa!";
});
